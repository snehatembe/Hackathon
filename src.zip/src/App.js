import LoginForm from './loginform'; 
function App() {
  return (
    <div className="App">
      <LoginForm /> 
    </div>
  );
}

export default App;
